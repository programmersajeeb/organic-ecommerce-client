"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  type KeyboardEvent as ReactKeyboardEvent,
  useCallback,
  useEffect,
  useId,
  useRef,
  useState,
  useSyncExternalStore,
} from "react";

import { getProtectedHref, HeaderActions } from "./header-actions";
import {
  HeaderCategoriesTrigger,
  HeaderCategoryNav,
} from "./header-category-nav";
import { HeaderIcon } from "./header-icons";
import { HeaderMobileDrawer } from "./header-mobile-drawer";
import { HeaderSearch } from "./header-search";
import type {
  HeaderLanguageId,
  HeaderLanguageOption,
  HeaderPanel,
  HeaderPanelKey,
  HeaderSearchConfig,
  HeaderSearchPayload,
  HeaderViewModel,
} from "./header.types";

type HeaderClientProps = Readonly<{
  data: HeaderViewModel;
  searchConfig: HeaderSearchConfig;
}>;

type HeaderLogoProps = Readonly<{
  onClick: () => void;
}>;

type HeaderCountBadgeProps = Readonly<{
  count: number;
}>;

type HeaderMobileNotificationActionProps = Readonly<{
  count: number;
  href: string;
  onCloseAll: () => void;
}>;

const DEFAULT_LANGUAGE_ID: HeaderLanguageId = "en";
const LANGUAGE_STORAGE_KEY = "gb-language";
const LANGUAGE_CHANGE_EVENT = "gb-language-change";
const HEADER_SCROLL_THRESHOLD = 8;
const NOTIFICATIONS_HREF = "/account/notifications";

function getClassName(...classNames: Array<string | false | null | undefined>) {
  return classNames.filter(Boolean).join(" ");
}

function normalizeSearchQuery(value: string) {
  return value.trim().replace(/\s+/g, " ");
}

function isHeaderLanguageId(
  value: string | null,
  options: readonly HeaderLanguageOption[],
): value is HeaderLanguageId {
  return options.some((option) => option.id === value);
}

function getFallbackLanguageId(
  options: readonly HeaderLanguageOption[],
): HeaderLanguageId {
  return (
    options.find((option) => option.id === DEFAULT_LANGUAGE_ID)?.id ??
    options[0]?.id ??
    DEFAULT_LANGUAGE_ID
  );
}

function getSelectedLanguageLabel(
  options: readonly HeaderLanguageOption[],
  selectedLanguage: HeaderLanguageId,
) {
  return (
    options.find((option) => option.id === selectedLanguage)?.label ??
    options[0]?.label ??
    "English"
  );
}

function getSafeStoredLanguage(
  options: readonly HeaderLanguageOption[],
): HeaderLanguageId {
  const fallbackLanguageId = getFallbackLanguageId(options);

  if (typeof window === "undefined") {
    return fallbackLanguageId;
  }

  try {
    const storedLanguage = window.localStorage.getItem(LANGUAGE_STORAGE_KEY);

    if (isHeaderLanguageId(storedLanguage, options)) {
      return storedLanguage;
    }
  } catch {
    return fallbackLanguageId;
  }

  return fallbackLanguageId;
}

function subscribeToLanguageStore(onStoreChange: () => void) {
  if (typeof window === "undefined") {
    return () => undefined;
  }

  window.addEventListener("storage", onStoreChange);
  window.addEventListener(LANGUAGE_CHANGE_EVENT, onStoreChange);

  return () => {
    window.removeEventListener("storage", onStoreChange);
    window.removeEventListener(LANGUAGE_CHANGE_EVENT, onStoreChange);
  };
}

function setStoredLanguage(language: HeaderLanguageId) {
  if (typeof window === "undefined") {
    return;
  }

  try {
    window.localStorage.setItem(LANGUAGE_STORAGE_KEY, language);
  } catch {
    // Storage can fail in restricted browser contexts.
  }

  window.dispatchEvent(new Event(LANGUAGE_CHANGE_EVENT));
}

function useStoredLanguage(options: readonly HeaderLanguageOption[]) {
  const getSnapshot = useCallback(
    () => getSafeStoredLanguage(options),
    [options],
  );

  const getServerSnapshot = useCallback(
    () => getFallbackLanguageId(options),
    [options],
  );

  return useSyncExternalStore(
    subscribeToLanguageStore,
    getSnapshot,
    getServerSnapshot,
  );
}

function getHeaderScrollSnapshot() {
  if (typeof window === "undefined") {
    return false;
  }

  return window.scrollY > HEADER_SCROLL_THRESHOLD;
}

function subscribeToHeaderScrollStore(onStoreChange: () => void) {
  if (typeof window === "undefined") {
    return () => undefined;
  }

  let animationFrameId: number | null = null;

  const handleScroll = () => {
    if (animationFrameId !== null) {
      return;
    }

    animationFrameId = window.requestAnimationFrame(() => {
      animationFrameId = null;
      onStoreChange();
    });
  };

  window.addEventListener("scroll", handleScroll, { passive: true });

  return () => {
    if (animationFrameId !== null) {
      window.cancelAnimationFrame(animationFrameId);
    }

    window.removeEventListener("scroll", handleScroll);
  };
}

function useHeaderScrollState() {
  return useSyncExternalStore(
    subscribeToHeaderScrollStore,
    getHeaderScrollSnapshot,
    () => false,
  );
}

function formatBadgeCount(count: number) {
  return count > 99 ? "99+" : String(count);
}

function getCartLabel(itemCount: number) {
  return itemCount === 1 ? `${itemCount} item` : `${itemCount} items`;
}

function getNotificationLabel(count: number) {
  return count === 1
    ? `${count} unread notification`
    : `${count} unread notifications`;
}

function getSearchHref(searchHref: string, query: string) {
  const searchParams = new URLSearchParams({
    q: query,
  });

  return `${searchHref}?${searchParams.toString()}`;
}

function getMenuItems(menu: HTMLElement) {
  return Array.from(
    menu.querySelectorAll<HTMLElement>(
      '[role="menuitem"], [role="menuitemradio"]',
    ),
  );
}

function focusMenuItem(menu: HTMLElement, index: number) {
  const menuItems = getMenuItems(menu);
  const targetItem = menuItems[index];

  targetItem?.focus();
}

function handleMenuKeyDown(event: ReactKeyboardEvent<HTMLDivElement>) {
  const menu = event.currentTarget;
  const menuItems = getMenuItems(menu);

  if (menuItems.length === 0) {
    return;
  }

  const activeElement = document.activeElement;
  const currentIndex = menuItems.findIndex((item) => item === activeElement);

  if (event.key === "Home") {
    event.preventDefault();
    focusMenuItem(menu, 0);
    return;
  }

  if (event.key === "End") {
    event.preventDefault();
    focusMenuItem(menu, menuItems.length - 1);
    return;
  }

  if (event.key === "ArrowDown") {
    event.preventDefault();

    const nextIndex =
      currentIndex >= 0 ? (currentIndex + 1) % menuItems.length : 0;

    focusMenuItem(menu, nextIndex);
    return;
  }

  if (event.key === "ArrowUp") {
    event.preventDefault();

    const nextIndex =
      currentIndex >= 0
        ? (currentIndex - 1 + menuItems.length) % menuItems.length
        : menuItems.length - 1;

    focusMenuItem(menu, nextIndex);
  }
}

function HeaderCountBadge({ count }: HeaderCountBadgeProps) {
  if (count <= 0) {
    return null;
  }

  return (
    <span className="gb-site-header__count" aria-hidden="true">
      {formatBadgeCount(count)}
    </span>
  );
}

function HeaderMobileNotificationAction({
  count,
  href,
  onCloseAll,
}: HeaderMobileNotificationActionProps) {
  return (
    <Link
      className="gb-site-header__mobile-button"
      href={href}
      aria-label={`View notifications, ${getNotificationLabel(count)}`}
      onClick={onCloseAll}
    >
      <HeaderIcon name="bell" />
      <HeaderCountBadge count={count} />
    </Link>
  );
}

function HeaderLogo({ onClick }: HeaderLogoProps) {
  return (
    <Link
      className="gb-site-header__logo"
      href="/"
      aria-label="365 SHOP home"
      onClick={onClick}
    >
      <span className="gb-site-header__logo-mark" aria-hidden="true">
        <span className="gb-site-header__logo-brand">
          <span className="gb-site-header__logo-number">365</span>
          <span className="gb-site-header__logo-cart">
            <HeaderIcon name="cart" />
          </span>
        </span>

        <span className="gb-site-header__logo-name">SHOP</span>
      </span>
    </Link>
  );
}

export function HeaderClient({ data, searchConfig }: HeaderClientProps) {
  const {
    accountLinks,
    cartSummary,
    counts,
    languageOptions,
    moreCategories,
    notifications,
    primaryCategories,
    trustItems,
    user,
    utilityLinks,
  } = data;

  const router = useRouter();

  const [activePanel, setActivePanel] = useState<HeaderPanel>(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const isScrolled = useHeaderScrollState();
  const selectedLanguage = useStoredLanguage(languageOptions);
  const headerRef = useRef<HTMLElement | null>(null);

  const languageMenuId = useId();
  const categoriesMenuId = useId();
  const accountMenuId = useId();
  const notificationsMenuId = useId();
  const moreMenuId = useId();
  const mobileDrawerId = useId();
  const desktopSearchId = useId();
  const mobileSearchId = useId();

  const selectedLanguageLabel = getSelectedLanguageLabel(
    languageOptions,
    selectedLanguage,
  );

  const notificationsHref = getProtectedHref(NOTIFICATIONS_HREF, user, true);
  const isLanguageMenuOpen = activePanel === "language";

  const headerClassName = getClassName(
    "gb-site-header",
    isScrolled && "gb-site-header--scrolled",
    isMobileMenuOpen && "gb-site-header--mobile-menu-open",
  );

  const closePanels = useCallback(() => {
    setActivePanel(null);
  }, []);

  const closeAll = useCallback(() => {
    setActivePanel(null);
    setIsMobileMenuOpen(false);
  }, []);

  const togglePanel = useCallback((panel: HeaderPanelKey) => {
    setActivePanel((currentPanel) => (currentPanel === panel ? null : panel));
  }, []);

  const openMobileMenu = useCallback(() => {
    setActivePanel(null);
    setIsMobileMenuOpen(true);
  }, []);

  const handleSelectLanguage = useCallback(
    (language: HeaderLanguageId) => {
      setStoredLanguage(language);
      closePanels();
    },
    [closePanels],
  );

  const handleSearchValueChange = useCallback((value: string) => {
    setSearchQuery(value);
  }, []);

  const handleSearch = useCallback(
    ({ query }: HeaderSearchPayload) => {
      const normalizedQuery = normalizeSearchQuery(query);

      if (!normalizedQuery) {
        return;
      }

      setSearchQuery(normalizedQuery);
      closeAll();
      router.push(getSearchHref(searchConfig.searchHref, normalizedQuery));
    },
    [closeAll, router, searchConfig.searchHref],
  );

  useEffect(() => {
    const handlePointerDown = (event: globalThis.PointerEvent) => {
      const target = event.target;

      if (!(target instanceof Node)) {
        return;
      }

      if (!headerRef.current?.contains(target)) {
        closePanels();
      }
    };

    const handleKeyDown = (event: globalThis.KeyboardEvent) => {
      if (event.key === "Escape") {
        closeAll();
      }
    };

    document.addEventListener("pointerdown", handlePointerDown);
    document.addEventListener("keydown", handleKeyDown);

    return () => {
      document.removeEventListener("pointerdown", handlePointerDown);
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [closeAll, closePanels]);

  useEffect(() => {
    if (!isMobileMenuOpen) {
      return;
    }

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    return () => {
      document.body.style.overflow = previousOverflow;
    };
  }, [isMobileMenuOpen]);

  return (
    <header ref={headerRef} className={headerClassName}>
      <div className="gb-site-header__topbar">
        <div className="gb-container-wide gb-site-header__topbar-inner">
          <div
            className="gb-site-header__trust-list"
            aria-label="Store trust benefits"
          >
            {trustItems.map((item) =>
              item.href ? (
                <Link
                  key={item.id}
                  className="gb-site-header__trust-item"
                  href={item.href}
                  aria-label={item.ariaLabel ?? item.label}
                  onClick={closePanels}
                >
                  <HeaderIcon name={item.icon} />
                  {item.label}
                </Link>
              ) : (
                <span
                  key={item.id}
                  className="gb-site-header__trust-item"
                  aria-label={item.ariaLabel}
                >
                  <HeaderIcon name={item.icon} />
                  {item.label}
                </span>
              ),
            )}
          </div>

          <div className="gb-site-header__utility-list">
            {utilityLinks.map((item) => (
              <Link
                key={item.id}
                className="gb-site-header__utility-link"
                href={item.href}
                aria-label={item.ariaLabel ?? item.label}
                onClick={closePanels}
              >
                <HeaderIcon name={item.icon} />
                {item.label}
              </Link>
            ))}

            {languageOptions.length > 0 ? (
              <div className="gb-site-header__language">
                <button
                  type="button"
                  className="gb-site-header__language-trigger"
                  aria-label={`Select language, current language is ${selectedLanguageLabel}`}
                  aria-expanded={isLanguageMenuOpen}
                  aria-controls={languageMenuId}
                  aria-haspopup="menu"
                  data-active={isLanguageMenuOpen ? "true" : undefined}
                  data-state={isLanguageMenuOpen ? "open" : "closed"}
                  onClick={() => togglePanel("language")}
                >
                  <HeaderIcon name="globe" />
                  <span>{selectedLanguageLabel}</span>
                  <HeaderIcon name="chevronDown" />
                </button>

                {isLanguageMenuOpen ? (
                  <div
                    id={languageMenuId}
                    className="gb-site-header__language-menu"
                    role="menu"
                    aria-label="Language options"
                    onKeyDown={handleMenuKeyDown}
                  >
                    {languageOptions.map((option) => (
                      <button
                        key={option.id}
                        type="button"
                        className="gb-site-header__language-option"
                        role="menuitemradio"
                        aria-checked={selectedLanguage === option.id}
                        onClick={() => handleSelectLanguage(option.id)}
                      >
                        <span>{option.label}</span>
                        <span>{option.nativeLabel}</span>
                      </button>
                    ))}
                  </div>
                ) : null}
              </div>
            ) : null}
          </div>
        </div>
      </div>

      <div className="gb-site-header__main">
        <div className="gb-container-wide gb-site-header__main-inner">
          <HeaderLogo onClick={closeAll} />

          <HeaderCategoriesTrigger
            activePanel={activePanel}
            categoriesMenuId={categoriesMenuId}
            primaryCategories={primaryCategories}
            moreCategories={moreCategories}
            onCloseAll={closeAll}
            onTogglePanel={togglePanel}
          />

          <HeaderSearch
            id={desktopSearchId}
            name={searchConfig.desktopInputName}
            label="Product search"
            placeholder={searchConfig.placeholder}
            emptyQueryMessage={searchConfig.emptyQueryMessage}
            source="desktop"
            value={searchQuery}
            onValueChange={handleSearchValueChange}
            onSearch={handleSearch}
          />

          <HeaderActions
            accountLinks={accountLinks}
            activePanel={activePanel}
            accountMenuId={accountMenuId}
            cartSummary={cartSummary}
            counts={counts}
            notifications={notifications}
            notificationsMenuId={notificationsMenuId}
            user={user}
            onCloseAll={closeAll}
            onTogglePanel={togglePanel}
          />
        </div>
      </div>

      <HeaderCategoryNav
        activePanel={activePanel}
        moreMenuId={moreMenuId}
        primaryCategories={primaryCategories}
        moreCategories={moreCategories}
        onCloseAll={closeAll}
        onTogglePanel={togglePanel}
      />

      <div className="gb-container-wide gb-site-header__mobile-main">
        <button
          type="button"
          className="gb-site-header__mobile-button"
          aria-label="Open menu"
          aria-expanded={isMobileMenuOpen}
          aria-controls={mobileDrawerId}
          aria-haspopup="dialog"
          onClick={openMobileMenu}
        >
          <HeaderIcon name="menu" />
        </button>

        <HeaderLogo onClick={closeAll} />

        <div className="gb-site-header__mobile-actions">
          <HeaderMobileNotificationAction
            count={counts.notifications}
            href={notificationsHref}
            onCloseAll={closeAll}
          />

          <Link
            className="gb-site-header__mobile-button"
            href={cartSummary.cartHref}
            aria-label={`View cart, ${getCartLabel(cartSummary.itemCount)}`}
            onClick={closeAll}
          >
            <HeaderIcon name="cart" />
            <HeaderCountBadge count={cartSummary.itemCount} />
          </Link>
        </div>
      </div>

      <div className="gb-container-wide gb-site-header__mobile-search">
        <HeaderSearch
          id={mobileSearchId}
          name={searchConfig.mobileInputName}
          label="Mobile product search"
          placeholder={searchConfig.placeholder}
          emptyQueryMessage={searchConfig.emptyQueryMessage}
          source="mobile"
          value={searchQuery}
          onValueChange={handleSearchValueChange}
          onSearch={handleSearch}
        />
      </div>

      <HeaderMobileDrawer
        accountLinks={accountLinks}
        cartSummary={cartSummary}
        counts={counts}
        isOpen={isMobileMenuOpen}
        languageOptions={languageOptions}
        mobileDrawerId={mobileDrawerId}
        moreCategories={moreCategories}
        primaryCategories={primaryCategories}
        selectedLanguage={selectedLanguage}
        user={user}
        utilityLinks={utilityLinks}
        onCloseAll={closeAll}
        onSelectLanguage={handleSelectLanguage}
      />
    </header>
  );
}