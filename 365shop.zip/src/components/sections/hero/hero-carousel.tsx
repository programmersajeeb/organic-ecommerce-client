"use client";

import Image from "next/image";
import Link from "next/link";
import {
  type FocusEvent,
  type KeyboardEvent,
  useCallback,
  useEffect,
  useId,
  useState,
} from "react";

import { HeroIcon } from "./hero-icons";
import type { HeroAction, HeroSectionViewModel } from "./hero.types";

type HeroCarouselProps = Readonly<{
  data: HeroSectionViewModel;
  className?: string;
}>;

function getClassName(...classNames: Array<string | false | undefined>) {
  return classNames.filter(Boolean).join(" ");
}

function getSafeDelay(delay: number | undefined) {
  if (!delay) {
    return 6500;
  }

  return Math.max(delay, 3500);
}

function getNextIndex(currentIndex: number, slideCount: number) {
  return (currentIndex + 1) % slideCount;
}

function getPreviousIndex(currentIndex: number, slideCount: number) {
  return (currentIndex - 1 + slideCount) % slideCount;
}

function HeroActionLink({ action }: Readonly<{ action: HeroAction }>) {
  const variant = action.variant ?? "primary";

  return (
    <Link
      aria-label={action.ariaLabel}
      className={getClassName(
        "gb-hero-carousel__action",
        variant === "secondary" && "gb-hero-carousel__action--secondary",
      )}
      href={action.href}
    >
      <span className="gb-hero-carousel__action-label">{action.label}</span>

      {action.icon ? (
        <HeroIcon className="gb-hero-carousel__action-icon" name={action.icon} />
      ) : null}
    </Link>
  );
}

export function HeroCarousel({ className, data }: HeroCarouselProps) {
  const carouselId = useId();
  const slides = data.slides;
  const slideCount = slides.length;

  const [activeIndex, setActiveIndex] = useState(0);
  const [isPointerPaused, setIsPointerPaused] = useState(false);
  const [isFocusPaused, setIsFocusPaused] = useState(false);
  const [isManualPaused, setIsManualPaused] = useState(false);

  const activeSlide = slides[activeIndex] ?? slides[0];
  const shouldAutoplay =
    Boolean(data.carousel.autoplay) && slideCount > 1 && !isManualPaused;
  const isTemporarilyPaused = isPointerPaused || isFocusPaused;
  const isAutoplayPaused = isManualPaused || isTemporarilyPaused;

  const goToSlide = useCallback(
    (index: number) => {
      if (slideCount <= 0) {
        return;
      }

      setActiveIndex(Math.min(Math.max(index, 0), slideCount - 1));
    },
    [slideCount],
  );

  const goToNextSlide = useCallback(() => {
    setActiveIndex((currentIndex) => getNextIndex(currentIndex, slideCount));
  }, [slideCount]);

  const goToPreviousSlide = useCallback(() => {
    setActiveIndex((currentIndex) =>
      getPreviousIndex(currentIndex, slideCount),
    );
  }, [slideCount]);

  useEffect(() => {
    if (slideCount <= 0) {
      return;
    }

    setActiveIndex((currentIndex) => Math.min(currentIndex, slideCount - 1));
  }, [slideCount]);

  useEffect(() => {
    if (!shouldAutoplay || isTemporarilyPaused) {
      return;
    }

    const autoplayTimer = window.setInterval(() => {
      setActiveIndex((currentIndex) => getNextIndex(currentIndex, slideCount));
    }, getSafeDelay(data.carousel.autoplayDelayMs));

    return () => {
      window.clearInterval(autoplayTimer);
    };
  }, [
    data.carousel.autoplayDelayMs,
    isTemporarilyPaused,
    shouldAutoplay,
    slideCount,
  ]);

  function handlePointerEnter() {
    if (data.carousel.pauseOnHover) {
      setIsPointerPaused(true);
    }
  }

  function handlePointerLeave() {
    setIsPointerPaused(false);
  }

  function handleFocus() {
    if (data.carousel.pauseOnFocus) {
      setIsFocusPaused(true);
    }
  }

  function handleBlur(event: FocusEvent<HTMLElement>) {
    const nextFocusedElement = event.relatedTarget;

    if (
      !nextFocusedElement ||
      !event.currentTarget.contains(nextFocusedElement)
    ) {
      setIsFocusPaused(false);
    }
  }

  function handleKeyDown(event: KeyboardEvent<HTMLElement>) {
    if (slideCount <= 1) {
      return;
    }

    if (event.key === "ArrowLeft") {
      event.preventDefault();
      goToPreviousSlide();
      return;
    }

    if (event.key === "ArrowRight") {
      event.preventDefault();
      goToNextSlide();
      return;
    }

    if (event.key === "Home") {
      event.preventDefault();
      goToSlide(0);
      return;
    }

    if (event.key === "End") {
      event.preventDefault();
      goToSlide(slideCount - 1);
    }
  }

  if (!activeSlide) {
    return null;
  }

  return (
    <section
      aria-label={data.carousel.ariaLabel}
      aria-roledescription="carousel"
      className={getClassName("gb-hero-carousel", className)}
      onBlur={handleBlur}
      onFocus={handleFocus}
      onKeyDown={handleKeyDown}
      onMouseEnter={handlePointerEnter}
      onMouseLeave={handlePointerLeave}
    >
      <div className="gb-hero-carousel__container">
        <div className="gb-hero-carousel__shell">
          <div aria-hidden="true" className="gb-hero-carousel__background" />
          <div aria-hidden="true" className="gb-hero-carousel__grid-pattern" />

          {slideCount > 1 ? (
            <div
              aria-label="Choose featured promotion"
              className="gb-hero-carousel__dots"
              role="tablist"
            >
              {slides.map((slide, index) => {
                const isActive = index === activeIndex;

                return (
                  <button
                    aria-controls={`${carouselId}-slide`}
                    aria-label={`Show promotion ${index + 1}: ${slide.eyebrow}`}
                    aria-selected={isActive}
                    className={getClassName(
                      "gb-hero-carousel__dot",
                      isActive && "gb-hero-carousel__dot--active",
                    )}
                    key={slide.id}
                    onClick={() => goToSlide(index)}
                    role="tab"
                    type="button"
                  >
                    <span className="gb-hero-carousel__dot-label">
                      {index + 1}
                    </span>
                  </button>
                );
              })}
            </div>
          ) : null}

          {data.carousel.autoplay && slideCount > 1 ? (
            <button
              aria-label={
                isAutoplayPaused
                  ? "Resume featured promotions autoplay"
                  : "Pause featured promotions autoplay"
              }
              className="gb-hero-carousel__pause-button"
              onClick={() => setIsManualPaused((currentValue) => !currentValue)}
              type="button"
            >
              {isAutoplayPaused ? "Play" : "Pause"}
            </button>
          ) : null}

          <article
            aria-label={`${activeIndex + 1} of ${slideCount}`}
            aria-live={isAutoplayPaused ? "polite" : "off"}
            aria-roledescription="slide"
            className="gb-hero-carousel__slide"
            id={`${carouselId}-slide`}
            key={activeSlide.id}
            role="tabpanel"
          >
            <div className="gb-hero-carousel__content">
              <div className="gb-hero-carousel__copy">
                <p className="gb-hero-carousel__eyebrow">
                  {activeSlide.eyebrow}
                </p>

                <h1 className="gb-hero-carousel__title">
                  <span>{activeSlide.title}</span>

                  {activeSlide.titleAccent ? (
                    <span className="gb-hero-carousel__title-accent">
                      {activeSlide.titleAccent}
                    </span>
                  ) : null}
                </h1>

                <p className="gb-hero-carousel__description">
                  {activeSlide.description}
                </p>
              </div>

              {activeSlide.features?.length ? (
                <ul className="gb-hero-carousel__features">
                  {activeSlide.features.map((feature) => (
                    <li className="gb-hero-carousel__feature" key={feature.id}>
                      <span className="gb-hero-carousel__feature-icon">
                        <HeroIcon name={feature.icon} />
                      </span>
                      <span>{feature.label}</span>
                    </li>
                  ))}
                </ul>
              ) : null}

              <div className="gb-hero-carousel__actions">
                <HeroActionLink action={activeSlide.primaryAction} />

                {activeSlide.secondaryAction ? (
                  <HeroActionLink action={activeSlide.secondaryAction} />
                ) : null}
              </div>
            </div>

            <div className="gb-hero-carousel__media">
              <div aria-hidden="true" className="gb-hero-carousel__media-glow" />

              <div className="gb-hero-carousel__product-stage">
                <Image
                  alt={activeSlide.image.alt}
                  className="gb-hero-carousel__image"
                  height={activeSlide.image.height}
                  priority={activeSlide.image.priority}
                  sizes="(max-width: 767px) 82vw, (max-width: 1199px) 42vw, 520px"
                  src={activeSlide.image.src}
                  width={activeSlide.image.width}
                />
              </div>

              {activeSlide.promoBadge ? (
                <div
                  aria-label={activeSlide.promoBadge.ariaLabel}
                  className="gb-hero-carousel__promo-badge"
                >
                  <span className="gb-hero-carousel__promo-value">
                    {activeSlide.promoBadge.value}
                  </span>
                  <span className="gb-hero-carousel__promo-label">
                    {activeSlide.promoBadge.label}
                  </span>
                </div>
              ) : null}

              {activeSlide.deliveryBadge ? (
                <div
                  aria-label={activeSlide.deliveryBadge.ariaLabel}
                  className="gb-hero-carousel__delivery-badge"
                >
                  <HeroIcon
                    className="gb-hero-carousel__delivery-icon"
                    name={activeSlide.deliveryBadge.icon}
                  />
                  <span>{activeSlide.deliveryBadge.label}</span>
                </div>
              ) : null}
            </div>
          </article>
        </div>
      </div>
    </section>
  );
}