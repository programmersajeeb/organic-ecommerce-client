export { HeroSection } from "./hero-section";
export { heroSectionData } from "./hero-data";

export type {
  HeroAction,
  HeroActionVariant,
  HeroCarouselConfig,
  HeroDeliveryBadge,
  HeroFeature,
  HeroIconName,
  HeroProductImage,
  HeroPromoBadge,
  HeroSectionViewModel,
  HeroSlide,
} from "./hero.types";