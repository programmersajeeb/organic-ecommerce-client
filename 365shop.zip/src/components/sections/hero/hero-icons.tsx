import type { ComponentPropsWithoutRef } from "react";
import type { LucideIcon } from "lucide-react";
import {
  ArrowRight,
  BadgePercent,
  Check,
  Clock3,
  Package,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  Truck,
  Zap,
} from "lucide-react";

import type { HeroIconName } from "./hero.types";

const HERO_ICONS = {
  arrowRight: ArrowRight,
  badgePercent: BadgePercent,
  check: Check,
  clock: Clock3,
  package: Package,
  shield: ShieldCheck,
  shoppingBag: ShoppingBag,
  sparkles: Sparkles,
  truck: Truck,
  zap: Zap,
} satisfies Record<HeroIconName, LucideIcon>;

type HeroIconProps = Omit<ComponentPropsWithoutRef<"svg">, "name"> &
  Readonly<{
    name: HeroIconName;
  }>;

export function HeroIcon({
  name,
  "aria-hidden": ariaHidden = true,
  focusable = false,
  ...props
}: HeroIconProps) {
  const Icon = HERO_ICONS[name];

  return <Icon aria-hidden={ariaHidden} focusable={focusable} {...props} />;
}