export type HeroIconName =
  | "arrowRight"
  | "badgePercent"
  | "check"
  | "clock"
  | "package"
  | "shield"
  | "shoppingBag"
  | "sparkles"
  | "truck"
  | "zap";

export type HeroActionVariant = "primary" | "secondary";

export type HeroAction = Readonly<{
  label: string;
  href: string;
  ariaLabel?: string;
  icon?: HeroIconName;
  variant?: HeroActionVariant;
}>;

export type HeroFeature = Readonly<{
  id: string;
  label: string;
  icon: HeroIconName;
}>;

export type HeroProductImage = Readonly<{
  src: string;
  alt: string;
  width: number;
  height: number;
  priority?: boolean;
}>;

export type HeroPromoBadge = Readonly<{
  label: string;
  value: string;
  ariaLabel?: string;
}>;

export type HeroDeliveryBadge = Readonly<{
  label: string;
  icon: HeroIconName;
  ariaLabel?: string;
}>;

export type HeroSlide = Readonly<{
  id: string;
  eyebrow: string;
  title: string;
  titleAccent?: string;
  description: string;
  image: HeroProductImage;
  primaryAction: HeroAction;
  secondaryAction?: HeroAction;
  features?: readonly HeroFeature[];
  promoBadge?: HeroPromoBadge;
  deliveryBadge?: HeroDeliveryBadge;
}>;

export type HeroCarouselConfig = Readonly<{
  ariaLabel: string;
  autoplay?: boolean;
  autoplayDelayMs?: number;
  pauseOnHover?: boolean;
  pauseOnFocus?: boolean;
}>;

export type HeroSectionViewModel = Readonly<{
  slides: readonly HeroSlide[];
  carousel: HeroCarouselConfig;
}>;