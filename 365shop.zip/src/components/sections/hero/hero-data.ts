import type { HeroSectionViewModel } from "./hero.types";

export const heroSectionData = {
  carousel: {
    ariaLabel: "Featured shopping promotions",
    autoplay: true,
    autoplayDelayMs: 6500,
    pauseOnFocus: true,
    pauseOnHover: true,
  },

  slides: [
    {
      id: "summer-mega-sale",
      eyebrow: "Summer Mega Sale",
      title: "Shop smarter with premium daily deals",
      titleAccent: "Up to 70% Off",
      description:
        "Discover curated essentials, trending gadgets, fashion picks, and home favorites with fast delivery and trusted service.",
      image: {
        src: "/placeholder-product.png",
        alt: "Premium shopping products collection",
        width: 720,
        height: 520,
        priority: true,
      },
      primaryAction: {
        label: "Shop Deals",
        href: "/search?sort=deals",
        ariaLabel: "Shop today's best deals",
        icon: "arrowRight",
        variant: "primary",
      },
      secondaryAction: {
        label: "Explore Categories",
        href: "/search",
        ariaLabel: "Explore product categories",
        icon: "shoppingBag",
        variant: "secondary",
      },
      features: [
        {
          id: "authentic-products",
          label: "100% Authentic Products",
          icon: "shield",
        },
        {
          id: "fast-delivery",
          label: "Fast Delivery",
          icon: "truck",
        },
        {
          id: "secure-shopping",
          label: "Secure Shopping",
          icon: "check",
        },
      ],
      promoBadge: {
        label: "Limited Offer",
        value: "70%",
        ariaLabel: "Limited offer up to 70 percent off",
      },
      deliveryBadge: {
        label: "Fast Delivery",
        icon: "truck",
        ariaLabel: "Fast delivery available",
      },
    },
    {
      id: "new-arrivals",
      eyebrow: "New Arrivals",
      title: "Fresh picks for your everyday lifestyle",
      titleAccent: "Just Landed",
      description:
        "Upgrade your shopping list with newly added products selected for quality, value, and modern everyday needs.",
      image: {
        src: "/placeholder-product.png",
        alt: "New arrival ecommerce products",
        width: 720,
        height: 520,
      },
      primaryAction: {
        label: "View New Arrivals",
        href: "/search?sort=newest",
        ariaLabel: "View newly arrived products",
        icon: "sparkles",
        variant: "primary",
      },
      secondaryAction: {
        label: "Track Order",
        href: "/track-order",
        ariaLabel: "Track your order",
        icon: "package",
        variant: "secondary",
      },
      features: [
        {
          id: "fresh-collection",
          label: "Fresh Collection",
          icon: "sparkles",
        },
        {
          id: "easy-returns",
          label: "Easy Returns",
          icon: "package",
        },
        {
          id: "quick-support",
          label: "24/7 Support",
          icon: "clock",
        },
      ],
      promoBadge: {
        label: "New Stock",
        value: "New",
        ariaLabel: "New stock available",
      },
      deliveryBadge: {
        label: "Quick Ship",
        icon: "zap",
        ariaLabel: "Quick shipping available",
      },
    },
    {
      id: "trusted-marketplace",
      eyebrow: "Trusted Marketplace",
      title: "Everything you need in one reliable shop",
      titleAccent: "365 Shop",
      description:
        "Enjoy a smooth ecommerce experience with protected checkout, visible cart actions, wishlist support, and customer-first service.",
      image: {
        src: "/placeholder-product.png",
        alt: "Trusted online marketplace shopping experience",
        width: 720,
        height: 520,
      },
      primaryAction: {
        label: "Start Shopping",
        href: "/search",
        ariaLabel: "Start shopping now",
        icon: "arrowRight",
        variant: "primary",
      },
      secondaryAction: {
        label: "Help Center",
        href: "/help-center",
        ariaLabel: "Visit help center",
        icon: "shield",
        variant: "secondary",
      },
      features: [
        {
          id: "protected-checkout",
          label: "Protected Checkout",
          icon: "shield",
        },
        {
          id: "best-value",
          label: "Best Value Picks",
          icon: "badgePercent",
        },
        {
          id: "all-day-shopping",
          label: "Shop Anytime",
          icon: "clock",
        },
      ],
      promoBadge: {
        label: "Best Value",
        value: "365",
        ariaLabel: "Best value shopping at 365 Shop",
      },
      deliveryBadge: {
        label: "On Time",
        icon: "check",
        ariaLabel: "On time delivery support",
      },
    },
  ],
} satisfies HeroSectionViewModel;