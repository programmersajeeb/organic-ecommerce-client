import Image from "next/image";
import Link from "next/link";
import {
  ArrowRight,
  Headphones,
  Headset,
  Home,
  Monitor,
  PackageSearch,
  Search,
  ShieldCheck,
  ShoppingBag,
  Truck,
  Watch,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

type NotFoundAction = Readonly<{
  href: "/" | "/track-order";
  label: string;
  icon: LucideIcon;
}>;

type NotFoundCategory = Readonly<{
  href: `/?category=${string}`;
  label: string;
  icon: LucideIcon;
}>;

type NotFoundHelpItem = Readonly<{
  title: string;
  description: string;
  icon: LucideIcon;
}>;

const primaryActions = [
  {
    href: "/",
    label: "Back to Home",
    icon: Home,
  },
  {
    href: "/track-order",
    label: "Track Order",
    icon: PackageSearch,
  },
] as const satisfies readonly NotFoundAction[];

const popularCategories = [
  {
    href: "/?category=electronics",
    label: "Electronics",
    icon: Monitor,
  },
  {
    href: "/?category=headphones",
    label: "Headphones",
    icon: Headphones,
  },
  {
    href: "/?category=smart-watch",
    label: "Smart Watch",
    icon: Watch,
  },
  {
    href: "/?category=home-kitchen",
    label: "Home & Kitchen",
    icon: Home,
  },
  {
    href: "/?category=bags-luggage",
    label: "Bags & Luggage",
    icon: ShoppingBag,
  },
] as const satisfies readonly NotFoundCategory[];

const helpItems = [
  {
    title: "Need Help?",
    description: "Our support team is ready to assist you.",
    icon: Headset,
  },
  {
    title: "Secure Shopping",
    description: "Continue shopping with a trusted checkout experience.",
    icon: ShieldCheck,
  },
  {
    title: "Fast Delivery",
    description: "Track your order and get delivery updates anytime.",
    icon: Truck,
  },
] as const satisfies readonly NotFoundHelpItem[];

export default function NotFoundPage() {
  return (
    <section
      className="gb-not-found-page"
      aria-labelledby="not-found-page-title"
    >
      <div className="gb-not-found-page__container">
        <div className="gb-not-found-page__shell">
          <div className="gb-not-found-page__content">
            <p className="gb-not-found-page__eyebrow">
              <Search
                aria-hidden="true"
                className="gb-not-found-page__button-icon"
                focusable="false"
              />
              Page not available
            </p>

            <p className="gb-not-found-page__code" aria-hidden="true">
              404
            </p>

            <h1 id="not-found-page-title" className="gb-not-found-page__title">
              Page Not Found
            </h1>

            <p className="gb-not-found-page__description">
              Sorry, the page you are looking for does not exist or may have
              been moved. Continue shopping or search for products from the
              store.
            </p>

            <div className="gb-not-found-page__actions">
              {primaryActions.map((action, index) => {
                const Icon = action.icon;
                const isSecondary = index > 0;

                return (
                  <Link
                    key={action.href}
                    href={action.href}
                    className={
                      isSecondary
                        ? "gb-not-found-page__button gb-not-found-page__button--secondary"
                        : "gb-not-found-page__button"
                    }
                  >
                    <Icon
                      aria-hidden="true"
                      className="gb-not-found-page__button-icon"
                      focusable="false"
                    />
                    {action.label}
                  </Link>
                );
              })}
            </div>

            <form
              className="gb-not-found-page__search"
              action="/"
              method="get"
              role="search"
              aria-label="Search products from not found page"
            >
              <label className="gb-sr-only" htmlFor="not-found-search">
                Search products
              </label>

              <Search
                aria-hidden="true"
                className="gb-not-found-page__search-icon"
                focusable="false"
              />

              <input
                id="not-found-search"
                type="search"
                name="q"
                className="gb-not-found-page__search-input"
                placeholder="Search for products, brands and more..."
                autoComplete="off"
                autoCapitalize="none"
                autoCorrect="off"
                enterKeyHint="search"
                spellCheck={false}
              />

              <button
                type="submit"
                className="gb-not-found-page__search-submit"
                aria-label="Search products"
              >
                <Search
                  aria-hidden="true"
                  className="gb-not-found-page__search-submit-icon"
                  focusable="false"
                />
              </button>
            </form>
          </div>

          <div className="gb-not-found-page__visual" aria-hidden="true">
            <picture className="gb-not-found-page__picture">
              <source
                media="(prefers-color-scheme: dark)"
                srcSet="/images/errors/404-shopping-illustration-dark.png"
              />
              <Image
                src="/images/errors/404-shopping-illustration-light.png"
                alt=""
                className="gb-not-found-page__image"
                width={724}
                height={543}
                sizes="(max-width: 767px) 84vw, (max-width: 1023px) 68vw, 44vw"
                priority
              />
            </picture>
          </div>
        </div>

        <section
          className="gb-not-found-page__categories"
          aria-labelledby="not-found-categories-title"
        >
          <div className="gb-not-found-page__section-header">
            <h2
              id="not-found-categories-title"
              className="gb-not-found-page__section-title"
            >
              Popular Categories
            </h2>

            <Link href="/" className="gb-not-found-page__section-link">
              View Store
              <ArrowRight
                aria-hidden="true"
                className="gb-not-found-page__section-link-icon"
                focusable="false"
              />
            </Link>
          </div>

          <ul className="gb-not-found-page__category-grid">
            {popularCategories.map((category) => {
              const Icon = category.icon;

              return (
                <li key={category.href}>
                  <Link
                    href={category.href}
                    className="gb-not-found-page__category-card"
                  >
                    <Icon
                      aria-hidden="true"
                      className="gb-not-found-page__category-image"
                      focusable="false"
                    />
                    <span className="gb-not-found-page__category-label">
                      {category.label}
                    </span>
                  </Link>
                </li>
              );
            })}
          </ul>
        </section>

        <section className="gb-not-found-page__help" aria-label="Shopping help">
          {helpItems.map((item) => {
            const Icon = item.icon;

            return (
              <article key={item.title} className="gb-not-found-page__help-item">
                <div className="gb-not-found-page__help-icon-shell">
                  <Icon
                    aria-hidden="true"
                    className="gb-not-found-page__help-icon"
                    focusable="false"
                  />
                </div>

                <div>
                  <h2 className="gb-not-found-page__help-title">
                    {item.title}
                  </h2>
                  <p className="gb-not-found-page__help-description">
                    {item.description}
                  </p>
                </div>
              </article>
            );
          })}
        </section>
      </div>
    </section>
  );
}